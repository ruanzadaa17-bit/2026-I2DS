﻿internal class Program
{
    private static void Main(string[] args)
    {
        // Primeiro Personagem
        Personagem personagem1 = new Personagem(
            "Mago", 2, 80, 20, 100);

        // Segundp Personagem 
        Personagem personagem2 = new Personagem(
            "Elfo", 4, 83, 20, 100);
            // Terceiro Personagem 
        Personagem Personagem3 = new Personagem(
            "Cavaleiro", 3,87, 20,100);
        // Exibindo os personagens
        Console.WriteLine("=== PERSONAGENS ===");

        Console.WriteLine("\nPersonagem 1 ");
        Console.WriteLine($"Nome: {personagem1.Nome}");
        Console.WriteLine($"Nível: {personagem1.Nivel}");
        Console.WriteLine($"Força: {personagem1.Forca}");
        Console.WriteLine($"Agilidade:  {personagem1.Agilidade}");

        Console.WriteLine("\nPersonagem 2");
        Console.WriteLine($"Nome: {personagem2.Nome}");
        Console.WriteLine($"Nível: {personagem2.Nivel}");
        Console.WriteLine($"Força: {personagem2.Forca}");
        Console.WriteLine($"Agilidade:  {personagem2.Agilidade}");
        

        Console.WriteLine("\nPersonagem 3");
        Console.WriteLine($"Nome: {personagem3.Nome}");
        Console.WriteLine($"Nível: {personagem3.Nivel}");
        Console.WriteLine($"Força: {personagem3.Forca}");
        Console.WriteLine($"Agilidasde: {personagem3.Agilidade}");
        

    }
    public class Personagem
    {
        public string Nome {get; private set;}
        public int Nivel {get; private set;}
        public int Forca {get; private set;}
        public int Agilidade {get; private set;}
        public int Vida {get; private set;}
        public int Experiencia {get; private set;}
        
}
}